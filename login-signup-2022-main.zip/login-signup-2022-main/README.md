# Login & Registration Form In PHP And MySQL 2022

version: 1.0.0

## TECHNOLOGIES

1. PHP
1. MYSQL
1. BOOTSTRAP 5
1. HTML
1. CSS

## Full Tutorial

[On Youtube](https://youtu.be/R7lFjX5kcYY)

## Authors

[Elias Abdurrahman](https://github.com/codingWithElias)
